from flask import Flask, redirect, render_template, request
from usuarios import Usuarios

app = Flask(__name__)

@app.route('/user/new')
def obtener_user1():
    return render_template("index.html")

@app.route('/user/new', methods=["POST"])
def crear_user():
    try:
        data = {
            "nombre": request.form["nombre"],
            "apellido": request.form["apellido"],
            "correo_electronico": request.form["correo_electronico"]
        }
        Usuarios.save(data)
        return redirect('/users')
    except Exception as e:
        return render_template("error.html", error=str(e))

@app.route('/users')
def obtener_user():
    usuarios = Usuarios.get_all()
    return render_template("resultado_users.html", usuarios=usuarios)

if __name__ == "__main__":
    app.run(debug=True)