from mysqlconnection import connectToMySQL

class Usuarios:
    def __init__(self, data):
        self.nombre = data['nombre']
        self.apellido = data['apellido']
        self.correo_electronico = data['correo_electronico']
        self.created_at = data['created_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM usuarios;"
        results = connectToMySQL('users_schema').query_db(query)
        usuarios = []
        for user in results:
            usuarios.append(cls(user))
        return usuarios

    @classmethod
    def save(cls, data):
        query = "INSERT INTO usuarios (nombre, apellido, correo_electronico, created_at, updated_at) VALUES (%(nombre)s, %(apellido)s, %(correo_electronico)s, NOW(), NOW());"
        return connectToMySQL('users_schema').query_db(query, data)